# ascendancy

Ok, this is the proper self-leak of the old version of Ascendancy. There isn't much to see here except for... actually nothing. I already posted the resolver that is in here on UC, and everything else is normal (apart from the broken bone stuff and incorrect hitscan/hitchance)
