#pragma once

/*namespace SDK
{
	class CUserCmd;
}

class CReveal
{
public:
	void CreateMove(SDK::CUserCmd* cmd);
}*/

//extern MsgFunc_ServerRankRevealAllFn MsgFunc_ServerRankRevealAll;