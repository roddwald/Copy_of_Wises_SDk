#pragma once
#pragma once

namespace SDK
{
	class CUserCmd;
}

class CFakeLag
{
public:
	void do_fakelag();
};

extern CFakeLag* fakelag;